# Skeletor
By "Tanman Tanner" Ghosen<br>
<br><br>
<b>Requirements:</b>
<br>Nodejs
<br>discord.js
<br>Enmap (https://enmap.evie.dev/install)
<br><br>
<b>Config</b>
(config.json)<br>
<blockquote>{
	"token": "",
}
</blockquote>
token = bot's token for logging in